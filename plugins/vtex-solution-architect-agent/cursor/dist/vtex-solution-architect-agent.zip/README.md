# VTEX Architect for Cursor

Cursor plugin for VTEX architecture, platform implementation, diagnostics, and
technical documentation. It combines four skills with three MCP servers.

## Included skills

| Skill | Purpose |
| --- | --- |
| `vtex-architect` | Architecture decisions, tradeoffs, ADRs, and migration planning |
| `vtex-expert` | Platform behavior, APIs, configuration, and implementation guidance |
| `vtex-inspector` | Live account inspection (via `vtex-account`), debugging, validation, and root-cause analysis |
| `vtex-architect-scribe` | Technical document drafting with an independent adversarial fact-check |

The skills mirror `codex-plugin-external`, adapted for Cursor.
`vtex-inspector` combines live-account inspection (through the `vtex-account`
MCP) with debugging and root-cause analysis.

## MCP servers

Declared in `mcp.json`:

- `vtex-architect-mcp`: external Atlas Streamable HTTP endpoint with OAuth.
- `vtex-developer`: current VTEX documentation and API search, temporarily run
  through `npx -y @vtex/developer-mcp`.
- `vtex-account`: live VTEX account inspection through
  `npx -y @miguel-carrera/vtex-account-mcp-server`. It reads VTEX session
  tokens from `~/.vtex/session/tokens.json`, so run `vtex login <account>`
  before using account inspection tools.

When a hosted `vtex-developer` endpoint is available, replace its `command` and
`args` in `mcp.json` with its `url`. No skill changes should be necessary.

## Requirements

- Cursor with plugin support (Customize → Plugins).
- Node.js 18 or newer for the `npx`-based `vtex-developer` and `vtex-account` MCPs.
- OAuth access to the external Atlas MCP endpoint.
- VTEX CLI login (`vtex login <account>`) for the `vtex-account` MCP.

## Install

This repository is a Cursor marketplace (`.cursor-plugin/marketplace.json` at
the repo root).

- **Team marketplace:** a Cursor admin imports
  `https://github.com/vtexprojects/ai-atlas-integrations` under
  **Dashboard → Plugins & MCPs**. Members then open **Customize** in the
  sidebar, find **VTEX Solution Architect Agent**, select **Install**, and
  choose project or user scope.

After installing:

1. Open **Cursor Settings → MCP** and click **Login** next to
   `vtex-architect-mcp` to complete the OAuth flow.
2. Confirm `vtex-developer` and `vtex-account` show as connected (both need
   `npx` on your `PATH`), and run `vtex login <account>` for account inspection.
3. Start a new Agent chat so the skills and MCP tools are loaded.

## Package

```bash
bash cursor-plugin-external/scripts/package.sh
```

Builds `cursor-plugin-external/dist/vtex-solution-architect-agent.zip`.
