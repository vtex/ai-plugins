# VTEX Architect for Codex

Codex plugin for VTEX architecture, platform implementation, diagnostics, and
technical documentation. It combines four skills with three MCP servers.

## Included skills

| Skill | Purpose |
| --- | --- |
| `vtex-architect` | Architecture decisions, tradeoffs, ADRs, and migration planning |
| `vtex-expert` | Platform behavior, APIs, configuration, and implementation guidance |
| `vtex-inspector` | Debugging, validation, and root-cause analysis |
| `vtex-architect-scribe` | Technical document drafting with an independent adversarial fact-check |

The architect, expert, and scribe use the newer guidance and reference material
from `claude-plugin-external`, adapted for Codex. Inspector still uses the
OpenAI-specific diagnostic scope and has not yet been updated to use the
`vtex-account` MCP.

## MCP servers

- `vtex-architect-mcp`: external Atlas Streamable HTTP endpoint with OAuth.
- `vtex-developer`: current VTEX documentation and API search, temporarily run
  through `npx -y @vtex/developer-mcp`.
- `vtex-account`: live VTEX account inspection through
  `npx -y @miguel-carrera/vtex-account-mcp-server`. It reads VTEX session
  tokens from `~/.vtex/session/tokens.json`, so run `vtex login <account>`
  before using account inspection tools.

When a hosted `vtex-developer` endpoint is available, replace its `command` and
`args` in `.mcp.json` with its `url`. No skill changes should be necessary.

## Requirements

- Codex desktop, CLI, or IDE extension with plugin support.
- Node.js 18 or newer for the `npx`-based `vtex-developer` and `vtex-account` MCPs.
- OAuth access to the external Atlas MCP endpoint.
- VTEX CLI login (`vtex login <account>`) for the `vtex-account` MCP.

After installation, authenticate Atlas from Codex's MCP settings or run:

```bash
codex mcp login vtex-architect-mcp
```

Use a new Codex task after installing or updating the plugin so its skills and
MCP tools are loaded into the task.

## Validate

From this repository, run:

```bash
python3 /Users/miguelcarrera/.codex/skills/.system/plugin-creator/scripts/validate_plugin.py codex-plugin-external
```

The absolute validator path above is for local development. CI should vendor
or invoke an equivalent validator rather than depending on a developer's home
directory.
