# VTEX Architect for Codex

Codex plugin for VTEX architecture, platform implementation, diagnostics, and
technical documentation. It combines four skills with two MCP servers.

## Included skills

| Skill | Purpose |
| --- | --- |
| `vtex-architect` | Architecture decisions, tradeoffs, ADRs, and migration planning |
| `vtex-expert` | Platform behavior, APIs, configuration, and implementation guidance |
| `vtex-inspector` | Debugging, validation, and root-cause analysis |
| `vtex-architect-scribe` | Technical document drafting with an independent adversarial fact-check |

The architect, expert, and scribe use the newer guidance and reference material
from `claude-plugin-external`, adapted for Codex. Inspector retains the
OpenAI-specific diagnostic scope because the newer Claude inspector requires a
third `vtex-account` MCP that this plugin intentionally does not bundle.

## MCP servers

- `vtex-architect-mcp`: external Atlas Streamable HTTP endpoint with OAuth.
- `vtex-developer`: current VTEX documentation and API search, temporarily run
  through `npx -y @vtex/developer-mcp`.

When a hosted `vtex-developer` endpoint is available, replace its `command` and
`args` in `.mcp.json` with its `url`. No skill changes should be necessary.

## Requirements

- Codex desktop, CLI, or IDE extension with plugin support.
- Node.js 18 or newer while `vtex-developer` uses the local `npx` transport.
- OAuth access to the external Atlas MCP endpoint.

After installation, authenticate Atlas from Codex's MCP settings or run:

```bash
codex mcp login vtex-architect-mcp
```

Use a new Codex task after installing or updating the plugin so its skills and
MCP tools are loaded into the task.

## Validate

From this repository, run:

```bash
python3 /Users/miguelcarrera/.codex/skills/.system/plugin-creator/scripts/validate_plugin.py codex-plugin-external
```

The absolute validator path above is for local development. CI should vendor
or invoke an equivalent validator rather than depending on a developer's home
directory.
